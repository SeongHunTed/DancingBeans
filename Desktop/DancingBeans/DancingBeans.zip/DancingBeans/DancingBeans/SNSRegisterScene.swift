import SwiftUI
import WebKit

struct SNSRegisterScene: View {
  var body: some View {
    VStack {
      // 네이버 로그인 이후 액션
      NaverVCRepresentable { email in
        snsAccount = email
        print("==네이버 로그인 결과: \(email)")
      }
      .showIf(condition: joinMethod == .naver)
      .frame(height: 0)
      }
      // 그 밑에 만들어야할 버튼들
    }
 }
      
