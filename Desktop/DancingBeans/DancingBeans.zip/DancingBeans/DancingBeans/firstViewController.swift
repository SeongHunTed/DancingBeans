//
//  firstViewController.swift
//  DancingBeans
//
//  Created by JAEHYEON on 2021/12/27.
//

import UIKit

class firstViewController: UIViewController {
    
    @IBAction func tapView(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    func recommendCoffee() {
        let alert = UIAlertController(title: "어서오세요",
                                      message: "따뜻한 라떼 드시겠어요?",
                                      preferredStyle: UIAlertController.Style.alert)
        
        let cancle = UIAlertAction(title: "아니요", style: .default, handler: nil)
        let ok = UIAlertAction(title: "네", style: .destructive, handler: {
            action in
        })
        
        alert.addAction(cancle)
        alert.addAction(ok)
        
        present(alert,animated: true, completion: nil)
        
    }

    func imageTapped(img: AnyObject) {
        self.recommendCoffee()
    }
    
    @IBAction func grabSomeCoffee(_ sender: Any) {
        self.recommendCoffee()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
