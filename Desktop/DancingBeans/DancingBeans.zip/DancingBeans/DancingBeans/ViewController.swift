//
//  ViewController.swift
//  TestAround
//
//  Created by JAEHYEON on 2021/12/27.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func tapView(_ sender: UITapGestureRecognizer) {
        print("Tapped!!")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
          
    }
    
    

}
